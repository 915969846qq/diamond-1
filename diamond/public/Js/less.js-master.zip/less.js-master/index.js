module.exports = require('./dist/less.cjs.js');
